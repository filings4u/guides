(async()=>{
 const m=document.querySelector("#authMessage"),f=document.querySelector("#loginForm");
 const show=(x,bad=true)=>{m.hidden=false;m.textContent=x;m.className="auth-message "+(bad?"bad":"good")};

 const existing=await S4UGuides.session();
 if(existing){
   try{
     await S4UGuides.bootstrap();
     location.replace("./");
     return;
   }catch{}
 }

 f.onsubmit=async e=>{
   e.preventDefault();
   m.hidden=true;

   const email=document.querySelector("#email").value.trim();
   const password=document.querySelector("#password").value;

   const {data,error}=await S4UGuides.sb.auth.signInWithPassword({email,password});

   if(error||!data.session){
     show(error?.message||"Unable to sign in.");
     return;
   }

   try{
     await S4UGuides.bootstrap();
   }catch(err){
     await S4UGuides.sb.auth.signOut();
     show(err.message||"Guide Builder access is not authorized.");
     return;
   }

   location.replace("./");
 };
})();